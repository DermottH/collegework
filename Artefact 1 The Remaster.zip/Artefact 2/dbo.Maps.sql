﻿CREATE TABLE [dbo].[Maps] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [Map_IMG]    NVARCHAR (MAX) NULL,
    [Map_Name]   NVARCHAR (MAX) NULL,
    [Map_Cup]    NVARCHAR (MAX) NULL,
    [Origin]     NVARCHAR (MAX) NULL,
    [BestTime]   NVARCHAR (MAX) NULL,
    [Difficulty] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_Maps] PRIMARY KEY CLUSTERED ([Id] ASC)
);

