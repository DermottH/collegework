﻿using Microsoft.EntityFrameworkCore;
using WebAppMKW.Models;
using WebAppMVC.Models;

namespace WebAppMVC.DBOperations
{
    public class CategoryDBContext :DbContext
    {
        public CategoryDBContext(DbContextOptions<CategoryDBContext>options) :base(options)
        { 
        
        }


        public DbSet<Category> Categories { get; set; }
        public DbSet<Character> Characters { get; set; }
        public DbSet<Map> Maps { get; set; }
    }
    //public class CharacterDBContext : DbContext
    //{
    //    public CharacterDBContext(DbContextOptions<CharacterDBContext> options) : base(options)
    //    {

    //    }

    //    public DbSet<Character> Characters { get; set; }
    //}
}
