﻿using System.ComponentModel.DataAnnotations;
using WebAppMKW.Models;

namespace WebAppMVC.Models
{
    public class CharacterVehicle
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public Character Character_Id { get; set; }

        public Category Vehicle_Id { get; set; }

        public Character WeightType { get; set; }


    }


}
