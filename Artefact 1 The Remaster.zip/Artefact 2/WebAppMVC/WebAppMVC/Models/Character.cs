﻿
using System.ComponentModel.DataAnnotations;

namespace WebAppMKW.Models
{
    public class Character
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Character_Name { get; set; }

        public string Character_Weight { get; set; }

        public string Character_UnlockReq { get; set; }

    }
}
