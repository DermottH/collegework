﻿using System.ComponentModel.DataAnnotations;

namespace WebAppMVC.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Vehicle_Name { get; set; }

        public string Vehicle_Type { get; set; }

        public string Vehicle_Weight { get; set; }

        public double Vehicle_Speed { get; set; }

        public string Vehicle_Drift { get; set; }

        public string Vehicle_UnlockReq { get; set; }

    }


}
