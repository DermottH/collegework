﻿
using System.ComponentModel.DataAnnotations;

namespace WebAppMKW.Models
{
    public class Map
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Map_IMG { get; set; }
        public string Map_Name { get; set; }

        public string Map_Cup { get; set; }

        public string Origin { get; set; }
        public string BestTime { get; set; }

        public string Difficulty { get; set; }

    }
}
