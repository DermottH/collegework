﻿using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAppMKW.Models;
using WebAppMVC.DBOperations;
using WebAppMVC.Models;

namespace WebAppMVC.Controllers
{
    public class CategoryController : Controller
    {
        private readonly CategoryDBContext _DbContext;

        public CategoryController(CategoryDBContext CopyofdbContext)
        {
            _DbContext = CopyofdbContext;
        }


        

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Index()
        {
            IEnumerable<Category> categoryList = _DbContext.Categories;

            return View(categoryList);
        }

        public IActionResult Characters()
        {
            IEnumerable<Character> categoryList = _DbContext.Characters;

            return View(categoryList);
        }

        public IActionResult Maps()
        {
            IEnumerable<Map> categoryList = _DbContext.Maps;

            return View(categoryList);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}