﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebAppMKW.Migrations
{
    /// <inheritdoc />
    public partial class inital1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VehicleName = table.Column<string>(name: "Vehicle_Name", type: "nvarchar(max)", nullable: false),
                    VehicleType = table.Column<string>(name: "Vehicle_Type", type: "nvarchar(max)", nullable: true),
                    VehicleWeight = table.Column<string>(name: "Vehicle_Weight", type: "nvarchar(max)", nullable: true),
                    VehicleSpeed = table.Column<double>(name: "Vehicle_Speed", type: "float", nullable: false),
                    VehicleDrift = table.Column<string>(name: "Vehicle_Drift", type: "nvarchar(max)", nullable: true),
                    VehicleUnlockReq = table.Column<string>(name: "Vehicle_UnlockReq", type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Characters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CharacterName = table.Column<string>(name: "Character_Name", type: "nvarchar(max)", nullable: false),
                    CharacterWeight = table.Column<string>(name: "Character_Weight", type: "nvarchar(max)", nullable: true),
                    CharacterUnlockReq = table.Column<string>(name: "Character_UnlockReq", type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Characters", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Maps",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MapIMG = table.Column<string>(name: "Map_IMG", type: "nvarchar(max)", nullable: false),
                    MapName = table.Column<string>(name: "Map_Name", type: "nvarchar(max)", nullable: true),
                    MapCup = table.Column<string>(name: "Map_Cup", type: "nvarchar(max)", nullable: true),
                    Origin = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BestTime = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Difficulty = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Maps", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "Characters");

            migrationBuilder.DropTable(
                name: "Maps");
        }
    }
}
